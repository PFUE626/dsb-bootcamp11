# New York Flights

# Description

This project showcases data transformation and visualization using R programming. It utilizes open data from the Tidyverse library to perform descriptive analytics, providing key insights and an overview of JFK Airport in 2013.

# Context

As a travel agency, understanding the characteristics of flights operating at JFK Airport is essential for optimizing services and providing better recommendations to customers. This project explores key aspects of JFK’s flight operations through the following research questions:

1. **How many airlines operate at JFK Airport?**
2. **How many flights does each airline operate annually?**
3. **What are the destinations accessible from JFK?**
4. **Which routes are the most popular?**
5. **When are the airport’s busiest hours?**

Beyond operational insights, we can also provide valuable information to customers. For example, we can recommend the **best airlines for the top 10 routes** based on **on-time departures** (or minimal delays) to help travelers manage expectations. Additionally, we can analyze **airline performance** by comparing **departure delays** and **arrival delays**—a well-performing airline should effectively manage its schedule to minimize arrival delays at destinations

### Prepare the environment for R programming

The online platform *Posit.cloud* is used as the main environment for coding and running scripts in R. Key libraries essential for this project include:

- **dplyr** – Used for data transformation tasks.
- **tidyr** – Used for data cleaning tasks.
- **ggplot2** – Used for creating 2D data visualizations.

```r
#install packages only once for an R environment
install.packages(dplyr)
install.packages(tidyr)
install.packages(nycflights13)
install.packages(ggplot2)
```

Next, the required libraries will be loaded. 

```r
library(dplyr)
library(tidyr)
library(nycflights13)
library(ggplot2)
```

Before starting analyzing the data, the sample data such as head and tail of the datasets, data types, and missing values are checked to understand the characteristics of the data.

```r
head(flights)
tail(flights)
glimpse(flights)
```

- Tail function shows 6 last rows data. We can see that some columns, such as dep_time, dep_delay, arr_time, arr_delay contain blanks.
    
    ![image.png](image.png)
    
- Glimpse show an overview of the dataframe.
    
    ![image.png](image%201.png)
    

### 0. Prepare the dataset containing only the flights originated or destinated at JFK airports

Only flights that originate from or arrive at JFK Airport are selected and stored in a new variable, **airport_JFK**. This table is then joined with the **airlines** table by matching the **carrier** column in both tables to obtain the airline **names**

```r

# Fitler only the focused dataset = JFK
airport_JFK <- flights %>% filter(origin =="JFK" | dest =="JFK")

# Join airline names
airport_JFK <- airport_JFK %>% 
  left_join(airlines, by = "carrier")
```

- The number of columns increases from 19 to 20 after the table join, as a new column, name, is added from the airlines table.
    
    ![image.png](image%202.png)
    

### 1. How many airlines operate at JFK Airports? & 2. **How many flights does each airline operate annually?**

Both questions can be answered with a single query by counting the number of flights per airline. This approach not only reveals the total number of airlines operating at JFK but also provides insights into their flight volume.

```r
airport_JFK %>% count(name) %>% arrange(desc(n)) %>%
  ggplot(aes(x=reorder(name,-n),y=n)) +
  geom_col() + 
  labs(title = "Flights by Airlines",x= "Airline", y= "Number of Flights") + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
```

![image.png](image%203.png)

There are **10 airlines** operated at JFK airport. **JetBlue Airways** operates the highest number of flights, with a total of **42,076** **flights**. This is **double** the number of flights operated by the second-highest airline, **Delta Air Lines**, which has **20,701** **flights**.

### 3.**What are the destinations accessible from JFK? & 4.Which routes are the most popular?**

The code below helps us review the total number of destinations from JFK. From this analysis, we find that there are **70 destinations** in total. Additionally, the **top 10 destinations** are sampled and displayed in the table on the right.

```r
airport_JFK %>% count(dest) %>%
  arrange(desc(n))
```

![image.png](image%204.png)

A variable, **top_10dest**, is created to store the **top 10 destinations** using the **slice_max()** function, **specifying the 10 highest values of n**. A column chart is then used to visualize the total number of flights per destination.

```r
top_10dest <- airport_JFK %>% 
  count(dest) %>%
  arrange(desc(n)) %>%
  slice_max(n,n=10)
  
ggplot(top_10dest,aes(x = reorder(dest,n,decreasing = TRUE), y= n)) + 
  geom_bar(stat = "identity", fill = "lightgray") + 
  labs(title = "Top 10 Destinations",
       x = "Destination Code",
       y = "Total Flights")
```

![image.png](image%205.png)

As a result, **LAX** is the top destination with **over 9,000 flights per year**, followed by **SFO** with approximately **7,500 flights**. **DCA** ranks **10th**, with around **3,200 flights per year**. While the chart is useful for identifying trends, the previously mentioned table is more effective for viewing exact numbers.

### 5.**When are the airport’s busiest hours?**

Some travelers are sensitive to crowded environments. Information about the airport's **busiest hours** can help them plan their flights and time at the airport more conveniently.

The **departure hour of flights** is used as an indicator to identify the **airport’s busiest hours**. It is calculated from the departure time (**dep_time**), which is provided as a numeric value in **HMM format**. **To extract the hour, dep_time is divided by 100 to obtain H** and then floored to remove the minutes, as the fraction is not needed.

**Counting dep_hour** gives the **total number of flights per hour for the entire year,** which can be difficult to interpret. To make the data more meaningful, a new column, **n, is created to store n / 365, representing the average number of flights per hour per day.**

```r
airport_JFK_busy <- airport_JFK %>% 
  mutate (dep_hour = floor(dep_time / 100)) %>%
  count(dep_hour) %>%
  mutate(n = n / 365) %>%
  arrange(desc(n))

ggplot(airport_JFK_busy,aes(dep_hour,n)) + 
  geom_bar(stat = "identity",alpha = 0.5) +
  geom_line() + 
  labs(title = "JFK Airport Busy Hours ",
      x = "Hour",
      y = "Number of Flights per Day") + 
  theme_minimal()
```

![image.png](image%206.png)

The **busiest hour** at JFK Airport is **8:00–8:59**, with approximately **27 flights**. This is followed by **16:00–16:59**, which sees around **25 flights**. Additionally, the afternoon period between **14:00–19:59** is consistently busy, with more than **20 flights per hour**. ****

**If clients are sensitive to crowded situations, we should recommend morning flights, as they tend to be less busy compared to the afternoon and evening peak hours.**

## Insight: T**he best airlines for the top 10 routes**

The departure delay time is used as an indicator to identify the best airlines for the top 10 routes. A new variable, **airport_JFK_delay_bonus_details** ,  is created to store a dataset from **airport_JFK**, which calculates **the average departure delay** (dep_delay) by **grouping** the data by **destination** and **airline names** by using group_by (dest, name).

```r
airport_JFK_delay_bonus_details <- airport_JFK %>%
  group_by(dest, name) %>%
  summarize(avg_dept_delay_des = mean(dep_delay, na.rm = TRUE)) 

ggplot(airport_JFK_delay_bonus_details %>% 
         filter(dest %in% c("LAX", "SFO", "BOS", "MCO", "SJU", "FLL", "LAS", "BUF", "MIA", "DCA")), 
       aes(x = dest, y = avg_dept_delay_des)) + 
  geom_bar(stat = "identity") + 
  geom_hline(yintercept = 0,color = "darkgreen") + 
  facet_wrap(~ name, ncol = 1) + 
  labs(title = "The Average Delay Departure Time at JFK Airport",
       x = NULL,
       y = "Average Departure Delay Minutes") +
  theme_minimal()

```

![image.png](image%207.png)

As a result, we can observe the **average departure delay time** for each airline. A **shorter column** represents a **shorter delay**. For example, travelers flying to **LAX** may consider **Delta Air Lines**, as its average delay is only **5 minutes**, compared to **10 minutes** for airlines like **American Airlines** and **Virgin America**.

Additionally, if a column shows a **negative value** (below the green line), it indicates that the flight **departs earlier than scheduled**. For instance, travelers flying to **BUF with Delta Air Lines** should be prepared to arrive at the gate **5 minutes earlier**, as the airline typically departs ahead of schedule.

## Insight: T**he most efficient airline**

To compare the **efficiency of airline operations**, the **average departure delay time** and **average arrival delay time** for each airline are plotted. This visualization helps assess how well airlines manage their schedules and minimize delays.

```r
airport_JFK_delay <- airport_JFK %>%
  group_by(name) %>%
  summarize(avg_dep_delay = mean(dep_delay, na.rm = TRUE),
            avg_arr_delay = mean(arr_delay,na.rm = TRUE)) #Lesson learn 4: without na.rm it will be NA
  
ggplot(airport_JFK_delay) + 
  geom_col(aes(name,avg_dep_delay, fill = "Departure"),alpha = 0.4) +
  geom_col(aes(name,avg_arr_delay,fill = "Arrival"), alpha = 0.4) +
  scale_fill_manual(values = c("Departure" = "blue", "Arrival" = "red")) +
  labs(x = "Airline", y = "Delay (minutes)", title = "Average Delay") + 
  theme_minimal()+
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
```

![image.png](image%208.png)

The plot shows **departure delay times** as **blue columns**, where **Endeavor Air** and **ExpressJet** typically experience delays of **around 20 minutes**, while most other airlines have delays of approximately **10 minutes**. **Hawaiian Airlines** and **US Airways** have shorter delays, typically **less than 10 minutes**.

Additionally, the **arrival delay times**, represented by **red columns**, are generally **lower than departure delays**. **American Airlines, United Airlines, and Virgin America** manage to keep their **arrival delays within 5 minutes**, despite having departure delays of around **10 minutes**.

Notably, **Delta Air Lines** and **Hawaiian Airlines** demonstrate **outstanding performance**, as their **arrival times are ahead of schedule**, indicated by the **red columns in the negative range**.

> ***"Without data, you're just another person with an opinion."* – W. Edwards Deming**
> 

Thank you for reading this far! Let’s use data to drive the world toward smarter and better decisions.